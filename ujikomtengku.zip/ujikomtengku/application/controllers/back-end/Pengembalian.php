<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengembalian extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();

        if ($this->session->userdata('logged') != TRUE) {
            redirect('login-sistem');
        }

        $this->load->model('Pengembalian_model', 'mdl');
    }

    public function index()
    {
        $data['page']             = 'back-end/form/pengembalian';
        $data['judul']            = 'Data Pengembalian';
        $data['resultPeminjaman'] = $this->mdl->findPeminjaman();

        $this->load->view('back-end/layout/header', $data);
        $this->load->view('back-end/layout/navbar');
        $this->load->view('back-end/layout/sidebar');
        $this->load->view('back-end/layout/content', $data);
        $this->load->view('back-end/layout/footer');
    }

    public function peminjaman($id)
    {
        $row = $this->mdl->findPeminjamanById($id);
        echo json_encode($row);
    }

    public function viewDetailPeminjaman($id)
    {
        $detail = $this->mdl->findPeminjamanDetail($id);

        $no = 1;
        foreach ($detail as $rs) {
            echo "
            <tr>
                <td>{$no}</td>
                <td>
                    {$rs->kode_buku}<br>
                    Judul: {$rs->judul}<br>
                    Pengarang: {$rs->pengarang}<br>
                    Penerbit: {$rs->penerbit}
                </td>
                <td>{$rs->qty}</td>
            </tr>
            ";
            $no++;
        }
    }

    public function save()
    {
        $peminjaman_id    = $this->input->post('peminjaman_id');
        $tgl_pengembalian = $this->input->post('tgl_pengembalian');
        $denda            = $this->input->post('denda');

        if (!$peminjaman_id) {
            echo json_encode(['status' => false]);
            return;
        }

        // ================= INSERT KE TABEL PENGEMBALIAN =================
        $data_pengembalian = [
            'peminjaman_id'    => $peminjaman_id,
            'tgl_pengembalian' => $tgl_pengembalian,
            'denda'            => $denda
        ];

        $this->db->insert('pengembalian', $data_pengembalian);

        // ================= UPDATE STATUS PEMINJAMAN =================
        $this->db->where('id', $peminjaman_id);
        $this->db->update('peminjaman', [
            'status' => 'dikembalikan'
        ]);

        // ================= UPDATE STOK BUKU =================
        $detail = $this->mdl->findPeminjamanDetail($peminjaman_id);

        foreach ($detail as $rs) {
            $this->db->set('stok', 'stok + ' . $rs->qty, FALSE);
            $this->db->where('id', $rs->buku_id);
            $this->db->update('buku');
        }

        echo json_encode(['status' => true]);
    }
}
