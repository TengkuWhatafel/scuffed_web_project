<div class="dashboard-header">
    <nav class="navbar navbar-expand-lg bg-dark fixed-top">
        <a class="navbar-brand text-reset" href="#">Perpustakaan Ujikom</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse">
            <span class="navbar-toggler-icon"></span>
        </button>
    </nav>
</div>
