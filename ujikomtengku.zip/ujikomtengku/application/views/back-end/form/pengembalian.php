<section class="content-header">
  <div class="container-fluid">

    <!-- CARD -->
    <div class="card card-primary">
      <div class="card-header">
        <h3 class="card-title">Data Pengembalian Buku</h3>
      </div>

      <div class="card-body">
        <div class="table-responsive">
          <table id="DataTables" class="table table-striped" style="width:100%">
            <thead>
              <tr>
                <th class="text-center">No</th>
                <th class="text-center">No Peminjaman</th>
                <th class="text-center">Detail Anggota</th>
                <th class="text-center">Denda</th>
                <th class="text-center">Status</th>
                <th class="text-center" style="width:15%">#</th>
              </tr>
            </thead>

            <tbody>
              <?php
              $no = 1;
              foreach ($resultPeminjaman as $rs) {

                $denda = 2000;
                $tgl_sekarang = date('Y-m-d');
                $jatuhTempo = new DateTime($rs->tgl_kembali);
                $dikembalikan = new DateTime($tgl_sekarang);

                if ($dikembalikan <= $jatuhTempo) {
                  $total = 0;
                } else {
                  $selisih = $jatuhTempo->diff($dikembalikan)->days;
                  $total = $selisih * $denda;
                }
              ?>
                <tr>
                  <td class="text-center"><?= $no++ ?></td>

                  <td class="text-center">
                    ID-<?= $rs->id ?><br>
                    Tgl Pinjam: <?= date('d-m-Y', strtotime($rs->tgl_pinjam)) ?><br>
                    Tgl Kembali: <?= date('d-m-Y', strtotime($rs->tgl_kembali)) ?>
                  </td>


                  <td>
                    <?= $rs->nis ?><br>
                    Nama: <?= $rs->nama ?><br>
                    Kelas: <?= $rs->kelas ?>
                  </td>

                  <td class="text-right">
                    <?= $total > 0 ? 'Rp ' . number_format($total, 0, ',', '.') : '-' ?>
                  </td>

                  <td class="text-center">
                    <div id="status<?= $rs->id ?>">
                      <?php if ($rs->status == 'dikembalikan') { ?>
                        <span class="badge badge-success">Dikembalikan</span>
                      <?php } else { ?>
                        <span class="badge badge-danger">Dipinjam</span>
                      <?php } ?>
                    </div>
                  </td>

                  <td class="text-center">
                    <button
                      class="btn btn-sm btn-primary"
                      onclick="pengembalian('<?= $rs->id ?>','<?= $total ?>')">
                      <i class="fa fa-tags"></i> Proses
                    </button>

                    <button
                      class="btn btn-sm btn-danger"
                      onclick="hapus('<?= $rs->id ?>')">
                      <i class="fa fa-trash"></i>
                    </button>
                  </td>
                </tr>
              <?php } ?>
            </tbody>

          </table>
        </div>
      </div>
    </div>
    <!-- END CARD -->

  </div>
</section>

<!-- MODAL -->
<div class="modal fade" id="modalPengembalian">
  <div class="modal-dialog modal-lg" style="max-width:90%">
    <div class="modal-content">

      <div class="modal-header">
        <h4 class="modal-title">Form Pengembalian Buku</h4>
        <button type="button" class="close" data-dismiss="modal">
          <span>&times;</span>
        </button>
      </div>

      <div class="modal-body">
        <div class="row">

          <div class="col-lg-4">
            <form id="form-pengembalian">

              <div class="form-group">
                <label>No Peminjaman</label>
                <input type="text" class="form-control form-control-sm" id="no_pinjam" name="no_pinjam">
                <input type="hidden" id="peminjaman_id" name="peminjaman_id">
              </div>

              <div class="form-group">
                <label>Tanggal Kembali</label>
                <input type="date" class="form-control form-control-sm" id="tgl_kembali" name="tgl_kembali">
              </div>

              <div class="form-group">
                <label>Tanggal Pengembalian</label>
                <input
                  type="date"
                  class="form-control form-control-sm"
                  id="tgl_pengembalian"
                  name="tgl_pengembalian"
                  value="<?= date('Y-m-d') ?>">
              </div>

              <div class="form-group">
                <label>Denda</label>
                <input type="text" class="form-control form-control-sm" id="denda" name="denda">
              </div>

            </form>
          </div>

          <div class="col-lg-8">
            <div class="table-responsive">
              <table class="table table-sm table-striped">
                <thead>
                  <tr>
                    <th class="text-center">No</th>
                    <th class="text-center">Detail Buku</th>
                    <th class="text-center">Qty</th>
                  </tr>
                </thead>
                <tbody id="viewListBuku"></tbody>
              </table>
            </div>
          </div>

          <div class="col-lg-12 text-right">
            <hr>
            <button class="btn btn-sm btn-primary" id="btn-simpan">
              <i class="fa fa-save"></i> Proses Pengembalian
            </button>
          </div>

        </div>
      </div>

    </div>
  </div>
</div>

<!-- SCRIPT -->
<script>
  $(document).ready(function() {

    $('#DataTables').DataTable({
      paging: true,
      ordering: false,
      responsive: true
    });

    $('#btn-simpan').click(function() {
      let formData = new FormData($('#form-pengembalian')[0]);

      $.ajax({
        type: 'POST',
        url: '<?= site_url("back-end/pengembalian/save") ?>',
        data: formData,
        contentType: false,
        processData: false,
        dataType: 'JSON',
        success: function(data) {
          if (data.status) {
            alert('Data pengembalian buku berhasil');
            location.reload();
          }
        }
      });

      return false;
    });

  });

  function pengembalian(id, total) {
    $.ajax({
      type: 'GET',
      url: '<?= site_url("back-end/pengembalian/peminjaman/") ?>' + id,
      dataType: 'JSON',
      success: function(data) {

        viewBuku(id);

        $('#no_pinjam').val("ID-" + data.id);
        $('#peminjaman_id').val(data.id);
        $('#tgl_kembali').val(data.tgl_kembali);
        $('#denda').val(total);

        $('#modalPengembalian').modal('show');
      }
    });
  }

  function viewBuku(id) {
    $.ajax({
      type: 'GET',
      url: '<?= site_url("back-end/pengembalian/viewDetailPeminjaman/") ?>' + id,
      success: function(data) {
        $('#viewListBuku').html(data);
      }
    });
  }
</script>