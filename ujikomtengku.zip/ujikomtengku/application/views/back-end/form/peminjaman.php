<section class="content-header">
    <div class="container-fluid">

        <div class="card card-primary">
            <div class="card-header">
                <h3 class="card-title">Data Peminjaman Buku</h3>
            </div>

            <div class="card-body">
                <div class="row">

                    <div class="col-lg-4">
                        <form id="form-peminjaman">

                            <!-- ROLE BASED ANGOTA -->
                            <?php if($this->session->userdata('role') == 'admin'): ?>

                                <div class="form-group">
                                    <label>Pilih Anggota</label>
                                    <select name="anggota_id" class="form-control form-control-sm" required>
                                        <option value="">-- Pilih Anggota --</option>
                                        <?php foreach($resultAnggota as $a): ?>
                                            <option value="<?= $a->id ?>">
                                                <?= $a->nama ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                            <?php else: ?>

                                <div class="form-group">
                                    <label>Data Anggota</label>
                                    <input type="text"
                                        class="form-control form-control-sm"
                                        value="<?= $this->session->userdata('nama') ?>"
                                        readonly>

                                    <input type="hidden"
                                        name="anggota_id"
                                        value="<?= $this->session->userdata('anggota_id') ?>">
                                </div>

                            <?php endif; ?>

                            <!-- TANGGAL -->
                            <div class="form-group">
                                <label>Tanggal Pinjam</label>
                                <input type="date"
                                    class="form-control form-control-sm"
                                    id="tgl_pinjam"
                                    name="tgl_pinjam"
                                    value="<?= date('Y-m-d') ?>">
                            </div>

                            <div class="form-group">
                                <label>Tanggal Kembali</label>
                                <input type="date"
                                    class="form-control form-control-sm"
                                    id="tgl_kembali"
                                    name="tgl_kembali">
                            </div>

                        </form>
                    </div>

                    <!-- LIST BUKU -->
                    <div class="col-lg-8">
                        <div class="form-group">
                            <code>Tambahkan buku yang akan dipinjam</code>
                            <button class="btn btn-sm btn-dark"
                                onclick="buku();">
                                <i class="fa fa-plus"></i> List Buku
                            </button>
                        </div>

                        <table class="table table-striped table-sm">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Detail Buku</th>
                                    <th>Qty</th>
                                    <th>#</th>
                                </tr>
                            </thead>
                            <tbody id="viewListBuku"></tbody>
                        </table>
                    </div>

                    <!-- BUTTON -->
                    <div class="col-lg-12 mt-3">
                        <button type="button"
                            class="btn btn-sm btn-primary"
                            id="btn-simpan">
                            <i class="fa fa-save"></i> Proses Peminjaman
                        </button>
                    </div>

                </div>
            </div>
        </div>

    </div>

</section>

<!-- MODAL LIST BUKU -->
<div class="modal fade" id="modalListBuku">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5>List Buku</h5>
                <button type="button" class="close" data-dismiss="modal">&times;</button>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-sm">
                    <thead>
                        <tr>
                            <th>Kode</th>
                            <th>Judul</th>
                            <th>Stok</th>
                            <th>#</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($resultBuku as $b): ?>
                        <tr>
                            <td><?= $b->kode_buku ?></td>
                            <td><?= $b->judul ?></td>
                            <td><?= $b->stok ?></td>
                            <td>
                                <button class="btn btn-sm btn-primary"
                                    onclick="pilihBuku('<?= $b->id ?>')">
                                    Pilih
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function(){

    viewBuku();
    loadPeminjamanSaya();

    $("#btn-simpan").click(function(){

        var form = new FormData(document.getElementById("form-peminjaman"));

        if($("#tgl_kembali").val() == ""){
            alert("Tanggal kembali wajib diisi");
            return false;
        }

        $.ajax({
            type:"POST",
            url:"<?= site_url('back-end/peminjaman/save') ?>",
            data:form,
            contentType:false,
            processData:false,
            dataType:"JSON",
            success:function(res){
                if(res.status === true){
                    alert("Peminjaman berhasil 🔥");
                    setTimeout(function(){
                        location.reload();
                    }, 500);
                }else{
                    alert("Gagal simpan!");
                }
            }
        });
    });
});

function buku(){
    $("#modalListBuku").modal('show');
}

function pilihBuku(id){
    $.post("<?= site_url('back-end/peminjaman/tambahBuku') ?>",
    {id_buku:id},
    function(res){
        if(res.Pesan){
            alert(res.Pesan);
        }else{
            viewBuku();
            $("#modalListBuku").modal('hide');
        }
    },"JSON");
}

function viewBuku(){
    $("#viewListBuku").load("<?= site_url('back-end/peminjaman/viewListBuku') ?>");
}

function loadPeminjamanSaya(){
    $("#tablePeminjamanSaya").load("<?= site_url('back-end/peminjaman/peminjamanSaya') ?>");
}
</script>
